#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

PORT="${PORT:-8000}"
HOST="127.0.0.1"
BIN_DIR="$ROOT_DIR/bin"
LOG_DIR="$ROOT_DIR/logs"
VENV_DIR="$ROOT_DIR/.venv"
mkdir -p "$BIN_DIR" "$LOG_DIR" "$ROOT_DIR/data"
export PATH="$BIN_DIR:$PATH"

need_cmd() {
  command -v "$1" >/dev/null 2>&1
}

install_cloudflared() {
  if need_cmd cloudflared; then
    return 0
  fi

  echo "cloudflared not found. Installing local cloudflared..."
  ARCH="$(uname -m)"
  case "$ARCH" in
    x86_64|amd64) CF_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64" ;;
    aarch64|arm64) CF_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64" ;;
    armv7l|armhf) CF_URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm" ;;
    *)
      echo "Unsupported architecture for auto cloudflared install: $ARCH"
      echo "Install cloudflared manually, then run this script again."
      exit 1
      ;;
  esac

  if need_cmd curl; then
    curl -L "$CF_URL" -o "$BIN_DIR/cloudflared"
  elif need_cmd wget; then
    wget -O "$BIN_DIR/cloudflared" "$CF_URL"
  else
    echo "curl/wget not found. Install curl or wget first."
    exit 1
  fi
  chmod +x "$BIN_DIR/cloudflared"
}

if ! need_cmd python3; then
  echo "python3 not found. Install Python 3.10+ first."
  exit 1
fi

install_cloudflared

if [ ! -d "$VENV_DIR" ]; then
  python3 -m venv "$VENV_DIR"
fi

source "$VENV_DIR/bin/activate"
python -m pip install --upgrade pip wheel >/dev/null
python -m pip install -r requirements.txt

echo "Stopping old local processes if they exist..."
pkill -f "uvicorn backend.main:app" >/dev/null 2>&1 || true
pkill -f "cloudflared tunnel --url http://$HOST:$PORT" >/dev/null 2>&1 || true
sleep 1

echo "Starting Deppl backend on http://$HOST:$PORT"
nohup python -m uvicorn backend.main:app --host "$HOST" --port "$PORT" > "$LOG_DIR/web.log" 2>&1 &
WEB_PID=$!
echo "$WEB_PID" > "$LOG_DIR/web.pid"

sleep 2

echo "Starting Cloudflared tunnel..."
nohup cloudflared tunnel --url "http://$HOST:$PORT" --no-autoupdate > "$LOG_DIR/cloudflared.log" 2>&1 &
CF_PID=$!
echo "$CF_PID" > "$LOG_DIR/cloudflared.pid"

PUBLIC_URL=""
for i in $(seq 1 40); do
  PUBLIC_URL="$(grep -oE 'https://[-a-zA-Z0-9.]+\.trycloudflare\.com' "$LOG_DIR/cloudflared.log" | head -n 1 || true)"
  if [ -n "$PUBLIC_URL" ]; then
    break
  fi
  sleep 1
done

if [ -n "$PUBLIC_URL" ]; then
  echo ""
  echo "Deppl is running: $PUBLIC_URL"
  echo "$PUBLIC_URL" > "$LOG_DIR/public_url.txt"
else
  echo ""
  echo "Backend started, but Cloudflared URL was not found yet."
  echo "Check logs/cloudflared.log"
fi

echo "Backend log: logs/web.log"
echo "Cloudflared log: logs/cloudflared.log"
