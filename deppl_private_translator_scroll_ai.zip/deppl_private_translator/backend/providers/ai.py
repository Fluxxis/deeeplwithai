from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

import aiohttp

from backend.providers.api_pool import RuntimeState, is_placeholder_key

LANG_NAMES = {
    "ru": "Russian",
    "en": "English",
    "de": "German",
    "auto": "the best matching language",
}


@dataclass
class AIResult:
    answer: str
    provider_used: str
    model_used: str
    warnings: List[str]


class AIService:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.ai_cfg = config.get("ai", {})
        self.state = RuntimeState()

    async def make_answer(
        self,
        original_text: str,
        translated_text: str,
        source_lang: str,
        target_lang: str,
        tone: str | None = None,
    ) -> AIResult:
        if not self.ai_cfg.get("enabled", True):
            return AIResult("", "disabled", "", [])

        answer_lang = self._resolve_answer_language(source_lang, target_lang)
        prompt = self._build_prompt(original_text, translated_text, source_lang, target_lang, answer_lang, tone)
        warnings: List[str] = []

        for provider in self.ai_cfg.get("provider_priority", ["gemini", "groq", "local_stub"]):
            pcfg = self.ai_cfg.get(provider, {})
            if provider != "local_stub" and not pcfg.get("enabled", False):
                continue
            try:
                if provider == "gemini":
                    result = await self._try_gemini(prompt, pcfg, warnings)
                elif provider == "groq":
                    result = await self._try_groq(prompt, pcfg, warnings)
                elif provider == "local_stub":
                    result = self._local_stub(original_text, translated_text, answer_lang)
                else:
                    result = None
                if result:
                    return result
            except Exception as exc:
                warnings.append(f"{provider}: {type(exc).__name__}")

        return AIResult("", "none", "", warnings)

    def _resolve_answer_language(self, source_lang: str, target_lang: str) -> str:
        choice = str(self.ai_cfg.get("answer_language", "target")).lower().strip()
        if choice == "source":
            return source_lang
        if choice == "target":
            return target_lang
        if choice in {"ru", "en", "de"}:
            return choice
        return target_lang

    def _build_prompt(
        self,
        original_text: str,
        translated_text: str,
        source_lang: str,
        target_lang: str,
        answer_lang: str,
        tone: str | None,
    ) -> str:
        tone_value = tone or self.ai_cfg.get("default_tone", "short")
        answer_language = LANG_NAMES.get(answer_lang, answer_lang)
        source_language = LANG_NAMES.get(source_lang, source_lang)
        target_language = LANG_NAMES.get(target_lang, target_lang)
        return (
            "You are a hidden assistant inside a private translator UI.\n"
            "Task: give a useful complete answer to the user's text.\n"
            "If the text is a question, answer it.\n"
            "If the text is a school task or instruction, solve it completely but keep it concise.\n"
            "If the text is a chat message, write a ready-to-send reply.\n"
            "Keep the full meaning and do not cut off the answer. Do not explain your reasoning.\n"
            "Do not add headings. Do not mention AI.\n"
            "Use as many short sentences as needed for a complete answer, but avoid extra commentary.\n"
            f"Tone: {tone_value}.\n"
            f"Answer language: {answer_language}.\n"
            f"Original language: {source_language}. Target translation language: {target_language}.\n\n"
            f"Original text:\n{original_text}\n\n"
            f"Translation:\n{translated_text}\n"
        )

    async def _try_gemini(self, prompt: str, pcfg: Dict[str, Any], warnings: List[str]) -> Optional[AIResult]:
        model = pcfg.get("model", "gemini-1.5-flash")
        base_url = pcfg.get("base_url", "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
        keys = pcfg.get("api_keys", []) or []
        timeout_seconds = int(self.ai_cfg.get("request_timeout_seconds", 25))
        cooldown_seconds = int(self.ai_cfg.get("cooldown_seconds_after_limit", 3600))
        payload = {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {
                "temperature": float(self.ai_cfg.get("temperature", 0.35)),
                "maxOutputTokens": int(self.ai_cfg.get("max_output_tokens", 80)),
            },
        }
        timeout = aiohttp.ClientTimeout(total=timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for idx, key in enumerate(keys):
                if is_placeholder_key(key):
                    continue
                if self.state.is_bad_key("gemini", idx) or self.state.is_on_cooldown("gemini", idx):
                    continue
                url = f"{base_url}/models/{model}:generateContent?key={key}"
                async with session.post(url, json=payload) as resp:
                    text_body = await resp.text()
                    if resp.status in {401, 403}:
                        self.state.mark_bad_key("gemini", idx, "auth_error")
                        warnings.append(f"gemini key {idx + 1}: auth error")
                        continue
                    if resp.status == 429 or "quota" in text_body.lower():
                        self.state.mark_cooldown("gemini", idx, cooldown_seconds)
                        warnings.append(f"gemini key {idx + 1}: limit")
                        continue
                    if resp.status >= 400:
                        warnings.append(f"gemini key {idx + 1}: http {resp.status}")
                        continue
                    data = await resp.json(content_type=None)
                    answer = self._parse_gemini_answer(data)
                    if answer:
                        return AIResult(answer, "gemini", model, warnings)
        return None

    def _parse_gemini_answer(self, data: Dict[str, Any]) -> str:
        candidates = data.get("candidates") or []
        for cand in candidates:
            parts = ((cand.get("content") or {}).get("parts") or [])
            chunks = [p.get("text", "") for p in parts if p.get("text")]
            if chunks:
                return self._clean_answer("\n".join(chunks))
        return ""

    async def _try_groq(self, prompt: str, pcfg: Dict[str, Any], warnings: List[str]) -> Optional[AIResult]:
        model = pcfg.get("model", "llama-3.1-8b-instant")
        url = pcfg.get("base_url", "https://api.groq.com/openai/v1/chat/completions")
        keys = pcfg.get("api_keys", []) or []
        timeout_seconds = int(self.ai_cfg.get("request_timeout_seconds", 25))
        cooldown_seconds = int(self.ai_cfg.get("cooldown_seconds_after_limit", 3600))
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": "Return only the final short answer. No explanations."},
                {"role": "user", "content": prompt},
            ],
            "temperature": float(self.ai_cfg.get("temperature", 0.35)),
            "max_tokens": int(self.ai_cfg.get("max_output_tokens", 80)),
        }
        timeout = aiohttp.ClientTimeout(total=timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for idx, key in enumerate(keys):
                if is_placeholder_key(key):
                    continue
                if self.state.is_bad_key("groq", idx) or self.state.is_on_cooldown("groq", idx):
                    continue
                headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
                async with session.post(url, json=payload, headers=headers) as resp:
                    text_body = await resp.text()
                    if resp.status in {401, 403}:
                        self.state.mark_bad_key("groq", idx, "auth_error")
                        warnings.append(f"groq key {idx + 1}: auth error")
                        continue
                    if resp.status == 429 or "rate_limit" in text_body.lower() or "quota" in text_body.lower():
                        self.state.mark_cooldown("groq", idx, cooldown_seconds)
                        warnings.append(f"groq key {idx + 1}: limit")
                        continue
                    if resp.status >= 400:
                        warnings.append(f"groq key {idx + 1}: http {resp.status}")
                        continue
                    data = await resp.json(content_type=None)
                    answer = self._parse_openai_compatible(data)
                    if answer:
                        return AIResult(answer, "groq", model, warnings)
        return None

    def _parse_openai_compatible(self, data: Dict[str, Any]) -> str:
        choices = data.get("choices") or []
        for choice in choices:
            message = choice.get("message") or {}
            content = message.get("content") or choice.get("text") or ""
            if content:
                return self._clean_answer(content)
        return ""

    def _local_stub(self, original_text: str, translated_text: str, answer_lang: str) -> AIResult:
        text = (translated_text or original_text or "").strip()
        if not text:
            return AIResult("", "local_stub", "heuristic", [])
        question_mark = "?" in text or text.lower().startswith(("why", "what", "how", "where", "when", "warum", "was", "wie", "wo", "wann"))
        if answer_lang == "ru":
            if question_mark:
                answer = "Ответь коротко и спокойно по смыслу сообщения."
            else:
                answer = "Понял, отвечу коротко и по делу."
        elif answer_lang == "de":
            if question_mark:
                answer = "Antworte kurz und ruhig auf die Frage."
            else:
                answer = "Alles klar, ich antworte kurz und direkt."
        else:
            if question_mark:
                answer = "Answer briefly and calmly."
            else:
                answer = "Got it, I will answer briefly."
        return AIResult(answer, "local_stub", "heuristic", [])

    def _clean_answer(self, answer: str) -> str:
        answer = (answer or "").strip()
        for prefix in ["Answer:", "Antwort:", "Ответ:", "AI:"]:
            if answer.lower().startswith(prefix.lower()):
                answer = answer[len(prefix):].strip()
        # Keep the complete answer. Earlier builds cut the hidden AI text to 260 characters,
        # which made longer school/task answers look unfinished.
        lines = [line.strip() for line in answer.splitlines() if line.strip()]
        answer = "\n".join(lines)
        max_chars = int(self.ai_cfg.get("max_answer_chars", 3500))
        if len(answer) > max_chars:
            answer = answer[:max_chars].rstrip()
        return answer
