from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

from backend.config_loader import STATE_PATH


def is_placeholder_key(value: str | None) -> bool:
    if value is None:
        return True
    key = str(value).strip()
    if not key:
        return True
    lowered = key.lower()
    if lowered in {"000", "0", "none", "null", "placeholder", "your_key_here", "api_key_here"}:
        return True
    if set(key) == {"0"}:
        return True
    return False


class RuntimeState:
    def __init__(self, path: Path = STATE_PATH) -> None:
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data: Dict[str, Any] = self._load()

    def _load(self) -> Dict[str, Any]:
        if not self.path.exists():
            return {"cooldowns": {}, "bad_keys": {}}
        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            return {"cooldowns": {}, "bad_keys": {}}

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")

    def key_id(self, provider: str, index: int) -> str:
        return f"{provider}:{index}"

    def is_on_cooldown(self, provider: str, index: int) -> bool:
        key_id = self.key_id(provider, index)
        until = float(self.data.get("cooldowns", {}).get(key_id, 0))
        return until > time.time()

    def mark_cooldown(self, provider: str, index: int, seconds: int) -> None:
        key_id = self.key_id(provider, index)
        self.data.setdefault("cooldowns", {})[key_id] = time.time() + max(1, int(seconds))
        self.save()

    def is_bad_key(self, provider: str, index: int) -> bool:
        key_id = self.key_id(provider, index)
        return bool(self.data.get("bad_keys", {}).get(key_id))

    def mark_bad_key(self, provider: str, index: int, reason: str = "auth_error") -> None:
        key_id = self.key_id(provider, index)
        self.data.setdefault("bad_keys", {})[key_id] = {"reason": reason, "time": time.time()}
        self.save()
