from __future__ import annotations

from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from backend.config_loader import load_config, root_path
from backend.providers.ai import AIService
from backend.providers.translation import LANG_LABELS, TranslationService

config = load_config()
translation_service = TranslationService(config)
ai_service = AIService(config)

app = FastAPI(title="DeepL Translator", version="1.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def no_cache_static_assets(request, call_next):
    response = await call_next(request)
    if request.url.path.startswith("/static/") or request.url.path in {"/", "/index.html"}:
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response

FRONTEND_DIR = root_path("frontend")
STATIC_DIR = FRONTEND_DIR / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


class TranslateRequest(BaseModel):
    text: str = Field(default="", max_length=5000)
    source_lang: str = "auto"
    target_lang: str = "ru"
    tone: Optional[str] = "short"
    with_ai: bool = False


class TranslateResponse(BaseModel):
    original_text: str
    translated_text: str
    source_lang: str
    source_label: str
    target_lang: str
    target_label: str
    provider_used: str
    ai_answer: str
    ai_provider_used: str
    ai_model_used: str
    warnings: list[str]


class AIAnswerRequest(BaseModel):
    original_text: str = Field(default="", max_length=5000)
    translated_text: str = Field(default="", max_length=5000)
    source_lang: str = "auto"
    target_lang: str = "ru"
    tone: Optional[str] = "short"


class AIAnswerResponse(BaseModel):
    ai_answer: str
    ai_provider_used: str
    ai_model_used: str
    warnings: list[str]


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(str(FRONTEND_DIR / "index.html"))


@app.get("/health")
async def health() -> dict:
    return {"ok": True, "app": config.get("app", {}).get("name", "DeepL Translator")}


@app.get("/api/config")
async def public_config() -> dict:
    app_cfg = config.get("app", {})
    ui_cfg = config.get("ui", {})
    return {
        "app_name": app_cfg.get("name", "DeepL Translator"),
        "brand_name": app_cfg.get("brand_name", "DeepL"),
        "logo_path": app_cfg.get("logo_path", "/static/assets/logo.svg"),
        "max_chars": int(app_cfg.get("max_chars", 500)),
        "hidden_ai_opacity": float(ui_cfg.get("hidden_ai_opacity", 0.18)),
        "hidden_ai_font_scale": float(ui_cfg.get("hidden_ai_font_scale", 0.92)),
        "default_source_lang": ui_cfg.get("default_source_lang", "auto"),
        "default_target_lang": ui_cfg.get("default_target_lang", "ru"),
        "show_marketing_blocks": bool(ui_cfg.get("show_marketing_blocks", True)),
    }


@app.get("/api/languages")
async def languages() -> dict:
    return {"languages": translation_service.languages()}


@app.post("/api/translate", response_model=TranslateResponse)
async def translate(req: TranslateRequest) -> TranslateResponse:
    max_chars = int(config.get("app", {}).get("max_chars", 500))
    text = (req.text or "")[:max_chars]
    if not text.strip():
        return TranslateResponse(
            original_text="",
            translated_text="",
            source_lang=req.source_lang,
            source_label=LANG_LABELS.get(req.source_lang, req.source_lang),
            target_lang=req.target_lang,
            target_label=LANG_LABELS.get(req.target_lang, req.target_lang),
            provider_used="none",
            ai_answer="",
            ai_provider_used="none",
            ai_model_used="",
            warnings=[],
        )

    try:
        translation = await translation_service.translate(text, req.source_lang, req.target_lang)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    ai_answer = ""
    ai_provider = "none"
    ai_model = ""
    warnings = list(translation.warnings)
    # Hidden AI answer is only requested when translating into Russian from another language.
    # Russian -> English/German stays a normal translation and does not spend AI API limits.
    should_call_ai = bool(req.with_ai and translation.detected_language != "ru" and req.target_lang == "ru")
    if should_call_ai:
        ai_result = await ai_service.make_answer(
            original_text=text,
            translated_text=translation.translated_text,
            source_lang=translation.detected_language,
            target_lang=req.target_lang,
            tone=req.tone,
        )
        ai_answer = ai_result.answer
        ai_provider = ai_result.provider_used
        ai_model = ai_result.model_used
        warnings.extend(ai_result.warnings)

    return TranslateResponse(
        original_text=text,
        translated_text=translation.translated_text,
        source_lang=translation.detected_language,
        source_label=LANG_LABELS.get(translation.detected_language, translation.detected_language),
        target_lang=req.target_lang,
        target_label=LANG_LABELS.get(req.target_lang, req.target_lang),
        provider_used=translation.provider_used,
        ai_answer=ai_answer,
        ai_provider_used=ai_provider,
        ai_model_used=ai_model,
        warnings=warnings,
    )


@app.post("/api/ai-answer", response_model=AIAnswerResponse)
async def ai_answer(req: AIAnswerRequest) -> AIAnswerResponse:
    source_lang = (req.source_lang or "auto").strip().lower()
    target_lang = (req.target_lang or "ru").strip().lower()

    # Hidden AI is only for English/German -> Russian.
    # Russian -> English/German stays only a normal translation and does not spend AI limits.
    if target_lang != "ru" or source_lang == "ru":
        return AIAnswerResponse(ai_answer="", ai_provider_used="none", ai_model_used="", warnings=[])

    ai_result = await ai_service.make_answer(
        original_text=req.original_text,
        translated_text=req.translated_text,
        source_lang=source_lang,
        target_lang=target_lang,
        tone=req.tone,
    )
    return AIAnswerResponse(
        ai_answer=ai_result.answer,
        ai_provider_used=ai_result.provider_used,
        ai_model_used=ai_result.model_used,
        warnings=ai_result.warnings,
    )


@app.get("/{path:path}")
async def spa_fallback(path: str) -> FileResponse:
    candidate = FRONTEND_DIR / path
    if candidate.exists() and candidate.is_file():
        return FileResponse(str(candidate))
    return FileResponse(str(FRONTEND_DIR / "index.html"))
