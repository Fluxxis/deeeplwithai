# DeepL Translator private clone

## Run

```bash
chmod +x autostart.sh
./autostart.sh
```

The script starts FastAPI and Cloudflared, then prints the public trycloudflare.com link.

## Important files

- `frontend/static/assets/logo.svg` — site logo and favicon.
- `config/config.yaml` — API keys, provider order, UI settings.
- `frontend/static/js/app.js` — frontend logic.
- `frontend/static/css/style.css` — responsive layout.

## Current behavior

- Supported translation directions:
  - English → Russian
  - Russian → English
  - German → Russian
  - Russian → German
- Translation starts on Enter.
- Shift + Enter keeps a line break.
- On iPad/Safari, Enter is also caught through `beforeinput` and newline fallback.
- Russian → English/German uses translation only. AI is not called.
- English/German → Russian shows translation first, then requests the hidden AI answer separately.
- The hidden AI answer is placed under the translation with low opacity.
- The Copy button copies the AI answer when it exists, then hides it. If there is no AI answer, it copies the translation.
- Static files use cache busting and no-cache headers, so Safari should not keep the old design/JS.

## API fallback

Translation provider order:

1. google_free
2. mymemory
3. libretranslate
4. simple

AI provider order:

1. Gemini
2. Groq
3. local_stub

Keys set to `000` are skipped automatically.
