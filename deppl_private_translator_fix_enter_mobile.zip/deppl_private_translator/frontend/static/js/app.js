const state = {
  appConfig: {
    max_chars: 500,
    hidden_ai_opacity: 0.08,
    hidden_ai_font_scale: 0.86,
    default_source_lang: 'ru',
    default_target_lang: 'en',
    show_marketing_blocks: true,
    brand_name: 'DeepL',
    app_name: 'DeepL Translator',
    logo_path: '/static/assets/logo.svg?v=3',
  },
  languages: [
    { code: 'auto', name: 'Detect language' },
    { code: 'en', name: 'English (American)' },
    { code: 'ru', name: 'Russian' },
    { code: 'de', name: 'German' },
  ],
  sourceLang: 'ru',
  targetLang: 'en',
  activeLangSide: 'source',
  lastTranslation: '',
  lastAi: '',
  timer: null,
  requestSeq: 0,
  allowNextNewline: false,
  enterLock: false,
};

const $ = (id) => document.getElementById(id);

const els = {
  sourceText: $('sourceText'),
  sourcePanel: $('sourcePanel'),
  resultPanel: $('resultPanel'),
  translationOutput: $('translationOutput'),
  hiddenAi: $('hiddenAi'),
  charCount: $('charCount'),
  maxChars: $('maxChars'),
  sourceLangBtn: $('sourceLangBtn'),
  targetLangBtn: $('targetLangBtn'),
  swapBtn: $('swapBtn'),
  languageModal: $('languageModal'),
  modalTitle: $('modalTitle'),
  modalClose: $('modalClose'),
  modalBackdrop: $('modalBackdrop'),
  languageSearch: $('languageSearch'),
  suggestedLanguages: $('suggestedLanguages'),
  allLanguages: $('allLanguages'),
  toast: $('toast'),
  announcement: $('announcement'),
  announcementClose: $('announcementClose'),
  copyResult: $('copyResult'),
  trustedBlock: $('trustedBlock'),
  businessBlock: $('businessBlock'),
  brandLogo: $('brandLogo'),
  brandName: $('brandName'),
  dictionaryText: $('dictionaryText'),
};

function langName(code) {
  const found = state.languages.find((lang) => lang.code === code);
  return found ? found.name : code;
}

function setText(el, text) {
  if (el) el.textContent = text;
}

function updateLanguageButtons() {
  setText(els.sourceLangBtn, langName(state.sourceLang));
  setText(els.targetLangBtn, langName(state.targetLang));
}

function updatePanelState() {
  const hasInput = Boolean(els.sourceText.value.trim());
  els.sourcePanel.classList.toggle('has-text', hasInput);
  const hasResult = Boolean((state.lastTranslation || '').trim() || (state.lastAi || '').trim() || (els.translationOutput.textContent || '').trim());
  els.resultPanel.classList.toggle('has-result', hasResult);
  if (els.dictionaryText) {
    els.dictionaryText.textContent = hasResult ? 'Click on a word to look it up.' : 'Click on a word to look it up.';
  }
}

function showToast(text = 'This feature is not available yet') {
  setText(els.toast, text);
  els.toast.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => els.toast.classList.remove('show'), 1800);
}

function applyPublicConfig(cfg) {
  state.appConfig = { ...state.appConfig, ...cfg };
  state.sourceLang = state.appConfig.default_source_lang || 'ru';
  state.targetLang = state.appConfig.default_target_lang || 'en';
  document.documentElement.style.setProperty('--hidden-opacity', String(state.appConfig.hidden_ai_opacity ?? 0.08));
  document.documentElement.style.setProperty('--hidden-scale', String(state.appConfig.hidden_ai_font_scale ?? 0.86));
  els.maxChars.textContent = String(state.appConfig.max_chars || 500);
  els.sourceText.maxLength = Number(state.appConfig.max_chars || 500);
  if (state.appConfig.logo_path && els.brandLogo) els.brandLogo.src = state.appConfig.logo_path;
  if (state.appConfig.brand_name && els.brandName) els.brandName.textContent = state.appConfig.brand_name;
  if (state.appConfig.app_name) document.title = state.appConfig.app_name;
  if (!state.appConfig.show_marketing_blocks) {
    els.trustedBlock.style.display = 'none';
    els.businessBlock.style.display = 'none';
  }
  updateLanguageButtons();
}

async function loadConfig() {
  try {
    const res = await fetch('/api/config', { cache: 'no-store' });
    if (!res.ok) return;
    const cfg = await res.json();
    applyPublicConfig(cfg);
  } catch (_) {}
}

async function loadLanguages() {
  try {
    const res = await fetch('/api/languages', { cache: 'no-store' });
    if (!res.ok) return;
    const data = await res.json();
    if (Array.isArray(data.languages) && data.languages.length) {
      state.languages = data.languages;
      updateLanguageButtons();
    }
  } catch (_) {}
}

function renderLanguages() {
  const search = (els.languageSearch.value || '').toLowerCase().trim();
  const selected = state.activeLangSide === 'source' ? state.sourceLang : state.targetLang;
  const suggestedCodes = state.activeLangSide === 'source' ? ['auto', 'en', 'ru', 'de'] : ['en', 'ru', 'de'];
  const suggested = state.languages.filter((lang) => suggestedCodes.includes(lang.code));
  const all = state.languages.filter((lang) => lang.code !== 'auto');

  function item(lang) {
    const btn = document.createElement('button');
    btn.textContent = lang.name;
    btn.dataset.code = lang.code;
    if (lang.code === selected) btn.classList.add('selected');
    if (state.activeLangSide === 'target' && lang.code === 'auto') {
      btn.classList.add('disabled-lang');
      btn.disabled = true;
    }
    btn.addEventListener('click', () => selectLanguage(lang.code));
    return btn;
  }

  els.suggestedLanguages.innerHTML = '';
  suggested
    .filter((lang) => !search || lang.name.toLowerCase().includes(search) || lang.code.includes(search))
    .forEach((lang) => els.suggestedLanguages.appendChild(item(lang)));

  els.allLanguages.innerHTML = '';
  all
    .filter((lang) => !search || lang.name.toLowerCase().includes(search) || lang.code.includes(search))
    .forEach((lang) => els.allLanguages.appendChild(item(lang)));
}

function openLanguageModal(side) {
  state.activeLangSide = side;
  setText(els.modalTitle, side === 'source' ? 'Translate from' : 'Translate to');
  els.languageSearch.value = '';
  renderLanguages();
  els.languageModal.classList.add('open');
  els.languageModal.setAttribute('aria-hidden', 'false');
  setTimeout(() => els.languageSearch.focus(), 40);
}

function closeLanguageModal() {
  els.languageModal.classList.remove('open');
  els.languageModal.setAttribute('aria-hidden', 'true');
}

function selectLanguage(code) {
  if (state.activeLangSide === 'source') {
    state.sourceLang = code;
  } else if (code !== 'auto') {
    state.targetLang = code;
  }
  if (state.sourceLang !== 'auto' && state.sourceLang === state.targetLang) {
    state.targetLang = state.sourceLang === 'ru' ? 'en' : 'ru';
  }
  updateLanguageButtons();
  closeLanguageModal();
}

function swapLanguages() {
  if (state.sourceLang === 'auto') {
    state.sourceLang = state.targetLang === 'ru' ? 'en' : 'ru';
  } else {
    const oldSource = state.sourceLang;
    state.sourceLang = state.targetLang;
    state.targetLang = oldSource;
  }
  updateLanguageButtons();
  if (state.lastTranslation) {
    els.sourceText.value = state.lastTranslation;
    state.lastTranslation = '';
    state.lastAi = '';
    setText(els.translationOutput, '');
    setText(els.hiddenAi, '');
    setText(els.charCount, String(els.sourceText.value.length));
    updatePanelState();
  }
}

function scheduleTranslate(delay = 80) {
  clearTimeout(state.timer);
  state.timer = setTimeout(translateNow, delay);
}

function setLoading(isLoading) {
  if (isLoading) {
    els.translationOutput.classList.add('loading');
    if (!els.translationOutput.textContent.trim()) setText(els.translationOutput, 'Translating...');
  } else {
    els.translationOutput.classList.remove('loading');
  }
}

function shouldAskAiFor(sourceLang, targetLang) {
  return targetLang === 'ru' && sourceLang !== 'ru' && sourceLang !== 'auto';
}

function currentText() {
  return els.sourceText.value.slice(0, state.appConfig.max_chars || 500).trim();
}

async function requestHiddenAi(seq, originalText, translatedText, sourceLang, targetLang) {
  if (!shouldAskAiFor(sourceLang, targetLang)) {
    state.lastAi = '';
    setText(els.hiddenAi, '');
    updatePanelState();
    return;
  }
  try {
    const res = await fetch('/api/ai-answer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({
        original_text: originalText,
        translated_text: translatedText,
        source_lang: sourceLang,
        target_lang: targetLang,
        tone: 'short',
      }),
    });
    const data = await res.json();
    if (seq !== state.requestSeq) return;
    if (!res.ok) throw new Error(data.detail || 'AI answer error');
    state.lastAi = data.ai_answer || '';
    setText(els.hiddenAi, state.lastAi);
  } catch (_) {
    if (seq !== state.requestSeq) return;
    state.lastAi = '';
    setText(els.hiddenAi, '');
  } finally {
    updatePanelState();
  }
}

async function translateNow() {
  clearTimeout(state.timer);
  const seq = ++state.requestSeq;
  const text = els.sourceText.value.slice(0, state.appConfig.max_chars || 500);
  setText(els.charCount, String(text.length));
  updatePanelState();
  if (!text.trim()) {
    setText(els.translationOutput, '');
    setText(els.hiddenAi, '');
    state.lastTranslation = '';
    state.lastAi = '';
    updatePanelState();
    return;
  }

  state.lastAi = '';
  setText(els.hiddenAi, '');
  setLoading(true);
  try {
    const res = await fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      cache: 'no-store',
      body: JSON.stringify({
        text,
        source_lang: state.sourceLang,
        target_lang: state.targetLang,
        tone: 'short',
        with_ai: false,
      }),
    });
    const data = await res.json();
    if (seq !== state.requestSeq) return;
    if (!res.ok) throw new Error(data.detail || 'Translation error');
    state.lastTranslation = data.translated_text || '';
    state.lastAi = '';
    setText(els.translationOutput, state.lastTranslation);
    setText(els.hiddenAi, '');
    if (state.sourceLang === 'auto' && data.source_label) setText(els.sourceLangBtn, data.source_label);
    updatePanelState();
    requestHiddenAi(seq, text, state.lastTranslation, data.source_lang, data.target_lang);
  } catch (err) {
    if (seq !== state.requestSeq) return;
    state.lastTranslation = '';
    state.lastAi = '';
    setText(els.translationOutput, 'Translation is unavailable for this request.');
    setText(els.hiddenAi, '');
  } finally {
    if (seq === state.requestSeq) setLoading(false);
    updatePanelState();
  }
}

async function copyText(text) {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    showToast('Copied');
  } catch (_) {
    showToast('Copy failed');
  }
}

function triggerEnterTranslate(event) {
  const isEnter = event.key === 'Enter' || event.key === 'NumpadEnter' || event.code === 'Enter' || event.code === 'NumpadEnter';
  if (!isEnter) return false;
  if (event.shiftKey) {
    state.allowNextNewline = true;
    setTimeout(() => { state.allowNextNewline = false; }, 60);
    return false;
  }
  event.preventDefault();
  event.stopPropagation();
  if (state.enterLock) return true;
  state.enterLock = true;
  setTimeout(() => { state.enterLock = false; }, 160);
  translateNow();
  return true;
}

function bindEvents() {
  document.querySelectorAll('.disabled-action').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      showToast();
    });
  });

  els.sourceLangBtn.addEventListener('click', () => openLanguageModal('source'));
  els.targetLangBtn.addEventListener('click', () => openLanguageModal('target'));
  els.swapBtn.addEventListener('click', swapLanguages);
  els.modalClose.addEventListener('click', closeLanguageModal);
  els.modalBackdrop.addEventListener('click', closeLanguageModal);
  els.languageSearch.addEventListener('input', renderLanguages);

  els.sourceText.addEventListener('input', () => {
    const max = state.appConfig.max_chars || 500;
    if (els.sourceText.value.length > max) els.sourceText.value = els.sourceText.value.slice(0, max);
    if (els.sourceText.value.includes('\n') && !state.allowNextNewline) {
      els.sourceText.value = els.sourceText.value.replace(/[\r\n]+/g, ' ').replace(/\s{2,}/g, ' ').trimEnd();
      translateNow();
    }
    setText(els.charCount, String(els.sourceText.value.length));
    updatePanelState();
  });

  ['keydown', 'keypress', 'keyup'].forEach((eventName) => {
    els.sourceText.addEventListener(eventName, triggerEnterTranslate);
  });

  els.sourceText.addEventListener('beforeinput', (event) => {
    if (event.inputType === 'insertLineBreak' && !state.allowNextNewline) {
      event.preventDefault();
      translateNow();
    }
  });

  document.addEventListener('keydown', (event) => {
    if (document.activeElement === els.sourceText) triggerEnterTranslate(event);
  }, true);

  els.copyResult.addEventListener('click', async () => {
    const textToCopy = state.lastAi || state.lastTranslation;
    await copyText(textToCopy);
    if (state.lastAi) {
      state.lastAi = '';
      setText(els.hiddenAi, '');
      updatePanelState();
    }
  });

  els.announcementClose.addEventListener('click', () => {
    els.announcement.style.display = 'none';
  });
}

async function init() {
  bindEvents();
  await loadConfig();
  await loadLanguages();
  updateLanguageButtons();
  setText(els.charCount, '0');
  updatePanelState();
}

init();
