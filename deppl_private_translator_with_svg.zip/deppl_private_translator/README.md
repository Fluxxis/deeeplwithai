Deppl private translator

Что внутри

1. Сайт с видом под твои скриншоты.
2. Телефонный вид и планшетный вид.
3. Логотип берется из frontend/static/assets/logo.svg.
4. Перевод работает для en ↔ ru и de ↔ ru.
5. Перевод сначала идет через локальный LibreTranslate, если он запущен.
6. Если локальный LibreTranslate не запущен, сайт пробует MyMemory без ключа.
7. Если всё упало, включается простой встроенный словарь для базовых фраз.
8. Ответ ИИ стоит под переводом и еле виден.
9. В config/config.yaml уже лежат 15 мест под Google AI Studio keys и 15 мест под Groq keys.
10. Ключи со значением 000 сайт пропускает сам.
11. Если ключ словил лимит или 429, сайт ставит его на cooldown и пробует следующий.
12. Запуск идет через Cloudflared tunnel.

Запуск

chmod +x autostart.sh
./autostart.sh

После запуска скрипт напечатает ссылку вида:
https://....trycloudflare.com

Где менять логотип

Замени файл:
frontend/static/assets/logo.svg

Имя файла оставь тем же:
logo.svg

Где вставлять API ключи

Открой:
config/config.yaml

Google AI Studio:
ai.gemini.api_keys

GroqCloud:
ai.groq.api_keys

Пример:

api_keys:
  - "AIza..."
  - "AIza..."
  - "000"

Все 000 сайт пропускает.
Пустые ключи сайт тоже пропускает.

Где выбрать язык скрытого ответа ИИ

В config/config.yaml:

ai:
  answer_language: "target"

Варианты:
target, ответ на языке перевода
source, ответ на языке исходного текста
ru, всегда русский
en, всегда английский
de, всегда немецкий

Где менять прозрачность скрытого текста

В config/config.yaml:

ui:
  hidden_ai_opacity: 0.18

Меньше число, слабее видно.
Больше число, сильнее видно.

Перевод без ключей

По умолчанию сайт пробует:
1. LibreTranslate local, если запущен на http://127.0.0.1:5000
2. MyMemory public fallback без ключа
3. Simple встроенный словарь

LibreTranslate локально через Docker

docker run -it -p 5000:5000 libretranslate/libretranslate

После этого Deppl начнет брать перевод с локального LibreTranslate.

Файлы для проверки

logs/web.log
logs/cloudflared.log
logs/public_url.txt

Что для вида

Products
Solutions
Pricing
Translate files
Translate speech
Use API
Log in
Start free trial
Toolbar
Marketing blocks

Что работает

Ввод текста
Выбор языка
Swap
Перевод
Скрытый ответ ИИ
Копирование перевода
Копирование скрытого ответа
Закрытие верхней полосы
