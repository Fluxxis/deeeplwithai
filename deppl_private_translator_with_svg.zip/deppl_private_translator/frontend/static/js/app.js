const state = {
  appConfig: {
    max_chars: 500,
    hidden_ai_opacity: 0.18,
    hidden_ai_font_scale: 0.92,
    default_source_lang: 'auto',
    default_target_lang: 'ru',
    show_marketing_blocks: true,
  },
  languages: [
    { code: 'auto', name: 'Detect language' },
    { code: 'en', name: 'English' },
    { code: 'ru', name: 'Russian' },
    { code: 'de', name: 'German' },
  ],
  sourceLang: 'auto',
  targetLang: 'ru',
  activeLangSide: 'source',
  lastTranslation: '',
  lastAi: '',
  timer: null,
};

const $ = (id) => document.getElementById(id);

const els = {
  sourceText: $('sourceText'),
  translationOutput: $('translationOutput'),
  hiddenAi: $('hiddenAi'),
  charCount: $('charCount'),
  maxChars: $('maxChars'),
  sourceLangBtn: $('sourceLangBtn'),
  targetLangBtn: $('targetLangBtn'),
  swapBtn: $('swapBtn'),
  languageModal: $('languageModal'),
  modalTitle: $('modalTitle'),
  modalClose: $('modalClose'),
  modalBackdrop: $('modalBackdrop'),
  languageSearch: $('languageSearch'),
  suggestedLanguages: $('suggestedLanguages'),
  allLanguages: $('allLanguages'),
  toast: $('toast'),
  announcement: $('announcement'),
  announcementClose: $('announcementClose'),
  copyTranslation: $('copyTranslation'),
  copyAi: $('copyAi'),
  trustedBlock: $('trustedBlock'),
  businessBlock: $('businessBlock'),
};

function langName(code) {
  const found = state.languages.find((lang) => lang.code === code);
  return found ? found.name : code;
}

function setText(el, text) {
  if (el) el.textContent = text;
}

function updateLanguageButtons() {
  setText(els.sourceLangBtn, langName(state.sourceLang));
  setText(els.targetLangBtn, langName(state.targetLang));
}

function showToast(text = 'This feature is not available yet') {
  setText(els.toast, text);
  els.toast.classList.add('show');
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => els.toast.classList.remove('show'), 1800);
}

function applyPublicConfig(cfg) {
  state.appConfig = { ...state.appConfig, ...cfg };
  state.sourceLang = state.appConfig.default_source_lang || 'auto';
  state.targetLang = state.appConfig.default_target_lang || 'ru';
  document.documentElement.style.setProperty('--hidden-opacity', String(state.appConfig.hidden_ai_opacity ?? 0.18));
  document.documentElement.style.setProperty('--hidden-scale', String(state.appConfig.hidden_ai_font_scale ?? 0.92));
  els.maxChars.textContent = String(state.appConfig.max_chars || 500);
  els.sourceText.maxLength = Number(state.appConfig.max_chars || 500);
  if (!state.appConfig.show_marketing_blocks) {
    els.trustedBlock.style.display = 'none';
    els.businessBlock.style.display = 'none';
  }
  updateLanguageButtons();
}

async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    if (!res.ok) return;
    const cfg = await res.json();
    applyPublicConfig(cfg);
  } catch (_) {}
}

async function loadLanguages() {
  try {
    const res = await fetch('/api/languages');
    if (!res.ok) return;
    const data = await res.json();
    if (Array.isArray(data.languages) && data.languages.length) {
      state.languages = data.languages;
      updateLanguageButtons();
    }
  } catch (_) {}
}

function renderLanguages() {
  const search = (els.languageSearch.value || '').toLowerCase().trim();
  const selected = state.activeLangSide === 'source' ? state.sourceLang : state.targetLang;
  const suggestedCodes = state.activeLangSide === 'source' ? ['auto', 'en', 'ru', 'de'] : ['ru', 'en', 'de'];
  const suggested = state.languages.filter((lang) => suggestedCodes.includes(lang.code));
  const all = state.languages.filter((lang) => lang.code !== 'auto');

  function item(lang) {
    const btn = document.createElement('button');
    btn.textContent = lang.name;
    btn.dataset.code = lang.code;
    if (lang.code === selected) btn.classList.add('selected');
    if (state.activeLangSide === 'target' && lang.code === 'auto') {
      btn.classList.add('disabled-lang');
      btn.disabled = true;
    }
    btn.addEventListener('click', () => selectLanguage(lang.code));
    return btn;
  }

  els.suggestedLanguages.innerHTML = '';
  suggested
    .filter((lang) => !search || lang.name.toLowerCase().includes(search) || lang.code.includes(search))
    .forEach((lang) => els.suggestedLanguages.appendChild(item(lang)));

  els.allLanguages.innerHTML = '';
  all
    .filter((lang) => !search || lang.name.toLowerCase().includes(search) || lang.code.includes(search))
    .forEach((lang) => els.allLanguages.appendChild(item(lang)));
}

function openLanguageModal(side) {
  state.activeLangSide = side;
  setText(els.modalTitle, side === 'source' ? 'Translate from' : 'Translate to');
  els.languageSearch.value = '';
  renderLanguages();
  els.languageModal.classList.add('open');
  els.languageModal.setAttribute('aria-hidden', 'false');
  setTimeout(() => els.languageSearch.focus(), 40);
}

function closeLanguageModal() {
  els.languageModal.classList.remove('open');
  els.languageModal.setAttribute('aria-hidden', 'true');
}

function selectLanguage(code) {
  if (state.activeLangSide === 'source') {
    state.sourceLang = code;
  } else if (code !== 'auto') {
    state.targetLang = code;
  }
  if (state.sourceLang !== 'auto' && state.sourceLang === state.targetLang) {
    state.targetLang = state.sourceLang === 'ru' ? 'en' : 'ru';
  }
  updateLanguageButtons();
  closeLanguageModal();
  scheduleTranslate(80);
}

function swapLanguages() {
  if (state.sourceLang === 'auto') {
    state.sourceLang = state.targetLang === 'ru' ? 'en' : 'ru';
  } else {
    const oldSource = state.sourceLang;
    state.sourceLang = state.targetLang;
    state.targetLang = oldSource;
  }
  updateLanguageButtons();
  if (state.lastTranslation) {
    els.sourceText.value = state.lastTranslation;
    state.lastTranslation = '';
    setText(els.translationOutput, '');
    setText(els.hiddenAi, '');
  }
  scheduleTranslate(80);
}

function scheduleTranslate(delay = 620) {
  clearTimeout(state.timer);
  state.timer = setTimeout(translateNow, delay);
}

function setLoading(isLoading) {
  if (isLoading) {
    els.translationOutput.classList.add('loading');
    if (!els.translationOutput.textContent.trim()) setText(els.translationOutput, 'Translating...');
  } else {
    els.translationOutput.classList.remove('loading');
  }
}

async function translateNow() {
  const text = els.sourceText.value.slice(0, state.appConfig.max_chars || 500);
  setText(els.charCount, String(text.length));
  if (!text.trim()) {
    setText(els.translationOutput, '');
    setText(els.hiddenAi, '');
    state.lastTranslation = '';
    state.lastAi = '';
    return;
  }

  setLoading(true);
  try {
    const res = await fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        source_lang: state.sourceLang,
        target_lang: state.targetLang,
        tone: 'short',
        with_ai: true,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.detail || 'Translation error');
    }
    state.lastTranslation = data.translated_text || '';
    state.lastAi = data.ai_answer || '';
    setText(els.translationOutput, state.lastTranslation);
    setText(els.hiddenAi, state.lastAi);
    if (state.sourceLang === 'auto' && data.source_label) {
      setText(els.sourceLangBtn, data.source_label);
    }
  } catch (err) {
    setText(els.translationOutput, 'Translation is unavailable for this request.');
    setText(els.hiddenAi, '');
  } finally {
    setLoading(false);
  }
}

async function copyText(text) {
  if (!text) return;
  try {
    await navigator.clipboard.writeText(text);
    showToast('Copied');
  } catch (_) {
    showToast('Copy failed');
  }
}

function bindEvents() {
  document.querySelectorAll('.disabled-action').forEach((btn) => {
    btn.addEventListener('click', (event) => {
      event.preventDefault();
      showToast();
    });
  });

  els.sourceLangBtn.addEventListener('click', () => openLanguageModal('source'));
  els.targetLangBtn.addEventListener('click', () => openLanguageModal('target'));
  els.swapBtn.addEventListener('click', swapLanguages);
  els.modalClose.addEventListener('click', closeLanguageModal);
  els.modalBackdrop.addEventListener('click', closeLanguageModal);
  els.languageSearch.addEventListener('input', renderLanguages);

  els.sourceText.addEventListener('input', () => {
    const max = state.appConfig.max_chars || 500;
    if (els.sourceText.value.length > max) {
      els.sourceText.value = els.sourceText.value.slice(0, max);
    }
    setText(els.charCount, String(els.sourceText.value.length));
    scheduleTranslate();
  });

  els.copyTranslation.addEventListener('click', () => copyText(state.lastTranslation));
  els.copyAi.addEventListener('click', () => copyText(state.lastAi));

  els.hiddenAi.addEventListener('dblclick', () => copyText(state.lastAi));

  els.announcementClose.addEventListener('click', () => {
    els.announcement.style.display = 'none';
  });
}

async function init() {
  bindEvents();
  await loadConfig();
  await loadLanguages();
  updateLanguageButtons();
  setText(els.charCount, '0');
}

init();
