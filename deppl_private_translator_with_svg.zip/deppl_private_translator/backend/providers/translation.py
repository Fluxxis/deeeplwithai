from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote

import aiohttp

LANG_LABELS = {
    "auto": "Detect language",
    "en": "English",
    "ru": "Russian",
    "de": "German",
}

SIMPLE_DICT = {
    ("en", "ru"): {
        "hello": "привет",
        "hi": "привет",
        "how are you": "как дела",
        "good morning": "доброе утро",
        "good night": "спокойной ночи",
        "thank you": "спасибо",
        "thanks": "спасибо",
        "yes": "да",
        "no": "нет",
        "sorry": "извини",
        "i don't know": "я не знаю",
        "what do you mean": "что ты имеешь в виду",
    },
    ("ru", "en"): {
        "привет": "hello",
        "как дела": "how are you",
        "доброе утро": "good morning",
        "спокойной ночи": "good night",
        "спасибо": "thank you",
        "да": "yes",
        "нет": "no",
        "извини": "sorry",
        "я не знаю": "i don't know",
        "что ты имеешь в виду": "what do you mean",
    },
    ("de", "ru"): {
        "hallo": "привет",
        "guten morgen": "доброе утро",
        "gute nacht": "спокойной ночи",
        "danke": "спасибо",
        "ja": "да",
        "nein": "нет",
        "entschuldigung": "извини",
        "was meinst du": "что ты имеешь в виду",
        "ich weiß nicht": "я не знаю",
    },
    ("ru", "de"): {
        "привет": "hallo",
        "доброе утро": "guten morgen",
        "спокойной ночи": "gute nacht",
        "спасибо": "danke",
        "да": "ja",
        "нет": "nein",
        "извини": "entschuldigung",
        "что ты имеешь в виду": "was meinst du",
        "я не знаю": "ich weiß nicht",
    },
}


@dataclass
class TranslationResult:
    translated_text: str
    detected_language: str
    provider_used: str
    warnings: List[str]


class TranslationService:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.tcfg = config.get("translation", {})
        self.allowed_languages = set(self.tcfg.get("allowed_languages", ["en", "ru", "de"]))
        self.allowed_pairs = set(self.tcfg.get("allowed_pairs", []))
        self.provider_priority = list(self.tcfg.get("provider_priority", ["libretranslate", "mymemory", "simple"]))
        self.bridge_language = self.tcfg.get("bridge_language", "en")

    def languages(self) -> List[Dict[str, str]]:
        order = ["auto", "en", "ru", "de"]
        return [{"code": code, "name": LANG_LABELS[code]} for code in order]

    async def translate(self, text: str, source_lang: str, target_lang: str) -> TranslationResult:
        text = (text or "").strip()
        if not text:
            return TranslationResult("", source_lang or "auto", "none", [])

        source = self._normalize_lang(source_lang)
        target = self._normalize_lang(target_lang)
        if source == "auto":
            source = self.detect_language(text)

        if source == target:
            return TranslationResult(text, source, "same_language", [])

        if not self._is_pair_allowed(source, target):
            raise ValueError(f"Language pair is not enabled: {source}:{target}")

        direct = await self._try_direct(text, source, target)
        if direct:
            return direct

        if source != self.bridge_language and target != self.bridge_language:
            first = await self._try_direct(text, source, self.bridge_language)
            if first and first.translated_text and first.translated_text != text:
                second = await self._try_direct(first.translated_text, self.bridge_language, target)
                if second:
                    second.warnings.append(f"Translated through {self.bridge_language}")
                    return second

        return TranslationResult(text, source, "unavailable", ["No translator provider returned a result"])

    async def _try_direct(self, text: str, source: str, target: str) -> Optional[TranslationResult]:
        warnings: List[str] = []
        for provider in self.provider_priority:
            try:
                if provider == "libretranslate":
                    translated = await self._libretranslate(text, source, target)
                elif provider == "mymemory":
                    translated = await self._mymemory(text, source, target)
                elif provider == "simple":
                    translated = self._simple_translate(text, source, target)
                else:
                    translated = None
                if translated and translated.strip() and translated.strip() != text.strip():
                    return TranslationResult(translated.strip(), source, provider, warnings)
                if translated and provider != "simple":
                    return TranslationResult(translated.strip(), source, provider, warnings)
            except Exception as exc:
                warnings.append(f"{provider}: {type(exc).__name__}")
                continue
        return None

    async def _libretranslate(self, text: str, source: str, target: str) -> Optional[str]:
        cfg = self.tcfg.get("libretranslate", {})
        if not cfg.get("enabled", False):
            return None
        base_urls = cfg.get("base_urls", []) or []
        timeout_seconds = int(cfg.get("timeout_seconds", 18))
        payload = {"q": text, "source": source, "target": target, "format": "text"}
        timeout = aiohttp.ClientTimeout(total=timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for base in base_urls:
                url = base.rstrip("/") + "/translate"
                try:
                    async with session.post(url, json=payload) as resp:
                        if resp.status >= 400:
                            continue
                        data = await resp.json(content_type=None)
                        return data.get("translatedText") or data.get("translated_text")
                except Exception:
                    continue
        return None

    async def _mymemory(self, text: str, source: str, target: str) -> Optional[str]:
        cfg = self.tcfg.get("mymemory", {})
        if not cfg.get("enabled", False):
            return None
        base_url = cfg.get("base_url", "https://api.mymemory.translated.net/get")
        timeout_seconds = int(cfg.get("timeout_seconds", 18))
        encoded_text = quote(text[:500])
        langpair = f"{source}|{target}"
        url = f"{base_url}?q={encoded_text}&langpair={langpair}"
        timeout = aiohttp.ClientTimeout(total=timeout_seconds)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status >= 400:
                    return None
                data = await resp.json(content_type=None)
                translated = (data.get("responseData") or {}).get("translatedText")
                if translated:
                    return translated
        return None

    def _simple_translate(self, text: str, source: str, target: str) -> Optional[str]:
        cfg = self.tcfg.get("simple", {})
        if not cfg.get("enabled", False):
            return None
        normalized = re.sub(r"\s+", " ", text.strip().lower()).strip(".!?… ")
        direct = SIMPLE_DICT.get((source, target), {})
        if normalized in direct:
            return direct[normalized]
        return None

    def _normalize_lang(self, code: str | None) -> str:
        code = (code or "auto").strip().lower()
        aliases = {"detect": "auto", "russian": "ru", "english": "en", "german": "de"}
        code = aliases.get(code, code)
        if code == "auto":
            return code
        if code not in self.allowed_languages:
            raise ValueError(f"Language is not enabled: {code}")
        return code

    def _is_pair_allowed(self, source: str, target: str) -> bool:
        return f"{source}:{target}" in self.allowed_pairs

    def detect_language(self, text: str) -> str:
        sample = text.lower()
        if re.search(r"[а-яёіїєґ]", sample):
            return "ru"
        if re.search(r"[äöüß]", sample):
            return "de"
        german_markers = [" ich ", " du ", " nicht ", " dass ", " was ", " wie ", " warum ", " danke", "hallo"]
        padded = f" {sample} "
        if any(marker in padded for marker in german_markers):
            return "de"
        return "en"
